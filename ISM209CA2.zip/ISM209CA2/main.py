from flask import Flask, render_template, request, session, redirect, url_for

from flask_sqlalchemy import SQLAlchemy


app = Flask(__name__) # create a flask app named app
db = SQLAlchemy(app)

app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:postgres@localhost/ismsdb'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = b'uW\x90g\x93\x84\xcf\xae-\xe2\xbe:E\xcf\xec\xcb\xd0\x85\x08\xae\xcf\xf7\x11\x97'
db = SQLAlchemy(app)

@app.route("/")
def home():
      return '''My name is Olanda Wonodi. This is my CA2 work.
      My GitHub URL is https://github.com/Ollyie/myISM209CA2.git'''
      # In the return statement above, Use your own name and GitHub URL

if __name__ == "__main__":
    app.run(port=5005)
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:bookexampledbpassword@localhost/bookexample'
    app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:bookexampledbpassword@localhost:5433/bookexample'
    FSADeprecationWarning: 'SQLALCHEMY_TRACK_MODIFICATIONS adds significant overhead and will be disabled by default in the future.'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
